const gerarTabuada = (numero) => {
    let texto = `** Tabuada do ${numero} **\n`;
    
    for (let i = 0; i <= 10; i++) {
        texto += `${numero} x ${i} = ${numero * i}\n`;
    }
    
    return texto;
};

function mostrarTabuada() {
    const num = Number(document.getElementById('numero').value);
    const divResultado = document.getElementById('resultado');

    if (num < 1 || num > 10 || !Number.isInteger(num)) {
        divResultado.textContent = "Por favor, digite um número inteiro entre 1 e 10.";
        return;
    }

    divResultado.textContent = gerarTabuada(num);
}