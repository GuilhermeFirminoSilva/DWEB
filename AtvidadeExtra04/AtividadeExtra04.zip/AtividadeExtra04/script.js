let numeros = [];

for (let i = 0; i < 5; i++) {
    let valor = Number(prompt(`Digite o ${i + 1}º número:`));
    numeros.push(valor);
}

let original = [...numeros];
let crescente = [...numeros].sort((a, b) => a - b);
let decrescente = [...crescente].reverse();

document.getElementById('resultado').innerHTML = `
    <p><strong>Array Original:</strong> ${original.join(', ')}</p>
    <p><strong>Ordem Decrescente:</strong> ${decrescente.join(', ')}</p>
`;