function calcularIMC() {
    const altura = Number(document.getElementById('altura').value);
    const peso = Number(document.getElementById('peso').value);
    const imc = peso / (altura * altura);
    let faixa = "";
    let classificacao = "";
    let grau = "";

    if (imc < 18.5) {
        faixa = "MENOR QUE 18,5";
        classificacao = "MAGREZA";
        grau = "0";
    } else if (imc <= 24.9) {
        faixa = "ENTRE 18,5 E 24,9";
        classificacao = "NORMAL";
        grau = "0";
    } else if (imc <= 29.9) {
        faixa = "ENTRE 25,0 E 29,9";
        classificacao = "SOBREPESO";
        grau = "I";
    } else if (imc <= 39.9) {
        faixa = "ENTRE 30,0 E 39,9";
        classificacao = "OBESIDADE";
        grau = "II";
    } else {
        faixa = "MAIOR QUE 40,0";
        classificacao = "OBESIDADE GRAVE";
        grau = "III";
    }

    document.getElementById('resultado').innerHTML = `
        <p><strong>Seu IMC:</strong> ${imc.toFixed(2)}</p>
        <table>
            <tr>
                <th>IMC</th>
                <th>CLASSIFICAÇÃO</th>
                <th>OBESIDADE (GRAU)</th>
            </tr>
            <tr>
                <td>${faixa}</td>
                <td>${classificacao}</td>
                <td>${grau}</td>
            </tr>
        </table>
    `;
}